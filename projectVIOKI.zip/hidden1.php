<?php
  require_once 'hidden.php';
?>

gg

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>VIOKI LEGENDS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="foto/vioki.jpg">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<style>
}
</style>
<body class="bg40">
  <nav class="navbar navbar-dark navbar-expand-lg bg-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img class="poto" src="/foto/vioki.jpg" width="40" height="44" alt="">
      VIOKI LEGENDS
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        <a class="nav-link" href="staff.php">Staff List</a>
        <a class="nav-link" href="#">Pricing</a>
        <a class="nav-link disabled" aria-disabled="true">Disabled</a>
      </div>
    </div>
  </div>
</nav>

<div class="container mt-5">
  <div class="row text-center">
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
     <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="bioyazan.php"><img src="foto/staff/yazan.jpg" alt="" width="100" class="mb-3"></a>
           <h5 class="mb-0">YAZAN</h5><span class="small text-uppercase text-muted"><span style="color:red;font-weight:bold">[OWNER]</span></span><br><p>[click image for infomation]</p>
          </div>
        </div>
      </div>
      <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="bioenki.php"><img src="foto/staff/enki.jpg" alt="" width="100" class="mb-3"></a>
           <h5 class="mb-0">ENKI</h5><span class="small text-uppercase text-muted"><span style="color:blue;font-weight:bold">[DEVELOPER 1]</span></span><br><p>[click image for infomation]</p>
          </div>
        </div>
        <br>
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="biochaos.php"><img src="foto/staff/chaos.jpg" alt="" width="100" class="mb-3"></a>
           <h5 class="mb-0">ITZFIREICEKUN</h5><span class="small text-uppercase text-muted"><span style="color:orange;font-weight:bold">[DEVELOPER 2]</span></span><br><p>[click image for infomation]</p>
          </div>
        </div>
        <br>
       <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="biotyo.php"><img src="foto/staff/tyo.jpg" alt="" width="100" class="mb-3"></a>
           <h5 class="mb-0">Touya</h5><span class="small text-uppercase text-muted"><span style="color:blue;font-weight:bold">[STAFF]</span></span><br><p>[click image for infomation]</p>
          </div>
        </div>
        <br>
       <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="biorexz.php"><img src="foto/staff/staffbaru.jpg" alt="" width="100" class="mb-3"></a>
           <h5 class="mb-0">Rexz</h5><span class="small text-uppercase text-muted"><span style="color:brown;font-weight:bold">[STAFF]</span></span><br><p>[click image for infomation]</p>
          </div>
        </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
  AOS.init();
</script>
</body>
</html>
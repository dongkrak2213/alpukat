<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="url" content="https://www.MinezeroFantasy.com/Staff/">
  <meta name="title" content="Minezero Fantasy">
  <meta name="og:url" content="https://www.MinezeroFantasy.com/Staff/">
  <meta name="og:title" content="Minezero Fantasy">
  <title>Staff List</title>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/e30691c300.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="shortcut icon" href="Minezero.png">
    <style>
      footer {
  text-align: center;
  padding: 15px 0 10px;
  background-color: dark;
  color: white;
  display: block;
  font-size: 14px;
  position: fixed;
   bottom:0;
   width:100%;
   height:60px;
}
.overlay {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}
.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, Sans-Serif;
}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup .close:hover {
  color: #06D85F;
}
.popup .contak {
  max-height: 30%;
  overflow: auto;
}
.ablot {
  text-decoration: none;
}
    </style>
</head>
<body style="background-color:#454647;">
  <nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand text-info" href="index.php">Minezero</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="/index.php">Home</a>
        <a class="nav-link" href="/staff.php">Staff List</a>
        <a class="nav-link" href="/topvote.php">Top Vote</a>
        <a class="nav-link" href="/ServerStatus.php">Server Status</a>
        <a class="nav-link" href="/openstaff">Open Staff</a>
      </div>
    </div>
  </div>
</nav>
<div class="container mt-5">
  <div class="row text-center">
    <h1 class="fw-bold text-white text-center" data-aos="fade-up" data-aos-duration="1000">STAFF</h1>
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
              <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><img src="player.png" alt="" width="100" class="mb-3">
           <h5 class="mb-0">AesnapGemink</h5><span class="small text-uppercase text-muted"><span style="color:red;font-weight:bold">[OWNER]</span></span><br><a class="ablot" href="https://m.youtube.com/@Aesnap"><i class="fa-brands fa-youtube" style="color:#ff0000;"></i> Aesnap</a>
          </div>
        </div>
      </div>

    <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><img src="player.png" alt="" width="100" class="mb-3">
           <h5 class="mb-0">RazzurFavBoy</h5><span class="small text-uppercase text-muted"><span style="color:#f05815;font-weight:bold">[CO Owner]</span></span><br><a class="ablot" href="https://www.youtube.com/@razz5884"><i class="fa-brands fa-youtube" style="color:#ff0000;"></i> Razz</a>
          </div>
        </div>
      </div>

<div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><img src="player.png" alt="" width="100" class="mb-3">
           <h5 class="mb-0">Itzfireicekun</h5><span class="small text-uppercase text-muted"><span style="color:#32b1b4;font-weight:bold">[DEVELOPER WEB]</span></span><br><a class="ablot" href="https://m.youtube.com/channel/UCRY1A-9TAEIv3PhL4UcDa4g"><i class="fa-brands fa-youtube" style="color:#ff0000;"></i> Dyront_</a>
          </div>
        </div>
      </div>
  </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
  <footer class="bg-dark text-info">
  <p class="footer-heading text-center text-uppercase text-white">&#9400; 2023 Minezero Fantasy</footer>
</body>
</html>
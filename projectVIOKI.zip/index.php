
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>VIOKI LEGENDS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="foto/vioki.jpg">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body class="bg40">
  <nav class="navbar navbar-dark navbar-expand-lg bg-dark fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img class="poto" src="/foto/vioki.jpg" width="40" height="44" alt="">
      VIOKI LEGENDS
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        <a class="nav-link" href="staff.php">Staff List</a>
        <a class="nav-link" href="#">Pricing</a>
        <a class="nav-link disabled" aria-disabled="true">Disabled</a>
      </div>
    </div>
  </div>
</nav>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center><img class="bg text-center" src="/foto/logo.png" width="50%" height="50%"alt=""></center>
<div class="judul text-center text-white">
  <b><h3 class="text1">VIOKI LEGENDS</h3></b>
  <b><h3 class="text2 text-center">Welcome to vioki legends <br> Semoga kalian betah dan nyaman di server ini!,jangan lupa menaati peraturan</h3></b>
</div>
<br>
<div class="container mt-5">
    <h1 class="fw-bold text-white text-center" data-aos="fade-up" data-aos-duration="1000">FITUR</h1>
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <i class="fa-solid fa-heart fa-3x text-dark mb-4" style="color:#ff0000;"></i>
                    <h5 class="mb-3 fw-bold">Survival RPG</h5>
                  </div>
                </div>
                <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <img src="foto/sins.png" width="40%" height="40%" class="text-dark mb-4" style="color:#ff0000;" alt="">
                    <h5 class="mb-3 fw-bold">Senjata Legendaris</h5>
                  </div>
                </div>
              <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <img src="foto/sit.png" width="40%" height="40%" class="text-dark mb-4" style="color:#ff0000;" alt="">
                    <h5 class="mb-3 fw-bold">Gsit</h5>
                  </div>
                </div>
              <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <img src="foto/mana.png" width="40%" height="40%" class="text-dark mb-4" style="color:#ff0000;" alt="">
                    <h5 class="mb-3 fw-bold">Mana Skills</h5>
                  </div>
                </div>
              <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <i class="fa-solid fa-cube fa-3x text-dark mb-4" style="color:#ff0000;"></i>
                    <h5 class="mb-3 fw-bold">ClearLag</h5>
                  </div>
                </div>
             <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <img src="foto/sc.png" width="40%" height="40%" class="text-dark mb-4" style="color:#ff0000;" alt="">
                    <h5 class="mb-3 fw-bold">Script Denizen Brutal Legends</h5>
                  </div>
                </div>
             <div class="container py-5 px-lg-5">
              <div class="row g-4">
                <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
                  <div class="feature-item bg-light rounded text-center p-4">
                    <img src="foto/vn.png" width="40%" height="40%" class="text-dark mb-4" style="color:#ff0000;" alt="">
                    <h5 class="mb-3 fw-bold">Simple Voice</h5>
                  </div>
                </div>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="https://kit.fontawesome.com/a2837e9c34.js" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
  AOS.init();
</script>
</body>
</html>
<?php
  require_once 'hidden.php';
?>
<style>
  @font-face {
    font-family: 'es';
    src: url('ice.otf');
  }
</style>
<br>
<br>
<br>
<br>



<div class="container mt-5">
  <div class="row text-center">
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
     <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="bioyazan.php"><img src="foto/staff/yazan.jpg" alt="" width="70%" height="70%" class="mb-3"></a>
          <h3 style="font-family: 'es';">BIODATA YAZAN</h3>
          <p style="text-align: left;" class="fw-bold">Nama: yazan</p>
          <p style="text-align: left;" class="fw-bold">Nama RP: yan</p>
          <p style="text-align: left;" class="fw-bold">peran: Antagonis</p>
          <p style="text-align: left;" class="fw-bold">jenis kelamin: Laki laki</p>
          <p style="text-align: left;" class="fw-bold">umur: -</p>
          <p style="text-align: left;" class="fw-bold">Senjata legendaris: <a href="" style="text-decoration: none; color: black;">Sin of Wrath</a></p>
          <p style="text-align: left;" class="fw-bold">Berasal dari:-</p>
          <p style="text-align: left;" class="fw-bold">kekuatan:-</p>
          <p style="text-align: left;" class="fw-bold">Lore: -</p>
          </div>
        </div>
      </div>
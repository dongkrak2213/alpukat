<?php
  require_once 'hidden.php';
?>

<style>
  @font-face {
    font-family: 'es';
    src: url('ice.otf');
  }
</style>
<br>
<br>
<br>
<br>



<div class="container mt-5">
  <div class="row text-center">
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
     <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="bioyazan.php"><img src="foto/staff/staffbaru.jpg" alt="" width="70%" height="70%" class="mb-3"></a>
          <h3 style="font-family: 'es';">BIODATA REXZ</h3>
          <p style="text-align: left;" class="fw-bold">Nama: rexz</p>
          <p style="text-align: left;" class="fw-bold">Nama RP: Raizen</p>
          <p style="text-align: left;" class="fw-bold">peran: Protagonis</p>
          <p style="text-align: left;" class="fw-bold">jenis kelamin: Laki laki</p>
          <p style="text-align: left;" class="fw-bold">umur: -</p>
          <p style="text-align: left;" class="fw-bold">Senjata legendaris: <a href="" style="text-decoration: none; color: black;">Future of Dark Blade</a></p>
          <p style="text-align: left;" class="fw-bold">Berasal dari:-</p>
          <p style="text-align: left;" class="fw-bold">kekuatan: Dark knight</p>
          <p style="text-align: left;" class="fw-bold">Lore: -</p>
          </div>
        </div>
      </div>
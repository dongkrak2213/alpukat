<?php
  require_once 'hidden.php';
?>

<style>
  @font-face {
    font-family: 'es';
    src: url('ice.otf');
  }
</style>

<div class="container mt-5">
  <div class="row text-center">
        <div class="container-xxl">
            <div class="container py-5 px-lg-5">
     <div class="col-xl-3 col-sm-6 mb-5">
        <div class="m-2 wow fadeInUp" data-wow-delay="0.5s"  data-aos="fade-up" data-aos-duration="1000">
          <div class="bg-white rounded shadow-lg py-5 px-4"><a href="bioyazan.php"><img src="foto/staff/chaos.jpg" alt="" width="70%" height="70%" class="mb-3"></a>
          <h3 style="font-family: 'es';">BIODATA ITZFIREICEKUN</h3>
          <p style="text-align: left;" class="fw-bold">Nama: Itzfireicekun</p>
          <p style="text-align: left;" class="fw-bold">Nama RP: Chaos</p>
          <p style="text-align: left;" class="fw-bold">peran: Protagonis</p>
          <p style="text-align: left;" class="fw-bold">jenis kelamin: Laki laki</p>
          <p style="text-align: left;" class="fw-bold">umur: -</p>
          <p style="text-align: left;" class="fw-bold">Senjata legendaris: <a href="" style="text-decoration: none; color: black;">Sin of Pride</a></p>
          <p style="text-align: left;" class="fw-bold">Berasal dari: dunia lain</p>
          <p style="text-align: left;" class="fw-bold">kekuatan: Time back, Time travel, ??? eye, ??? eye</p>
          <p style="text-align: left;" class="fw-bold">Lore: Seseorang anak laki laki yang terlempar ke dunia vioki legends dengan membawa kekuatan misterius, dan dia mencari cara pulang kedunia nya,dan mencari tau tentang dunia itu.</p>
          </div>
        </div>
      </div>